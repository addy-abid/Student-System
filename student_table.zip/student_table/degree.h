#include <iostream>
#ifndef DEGREE_H
#define DEGREE_H

using namespace std;


enum DegreeProgram { SECURITY, NETWORK, SOFTWARE };


#endif
